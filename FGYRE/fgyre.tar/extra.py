####################################################################################################
def cdtime2str(date, year=True, month=False, day=False, hour=False, minute=False, second=False,\
                   **kwargs) : 
    """
    Transform a list of component time (from cdms) to a list of string
    Usage: cdtime2str(date, year=True, month=False, day=False,
       hour=False, minute=False, second=False, **kwargs)
    """
    print("> cdtime2str")
    output = []
    for zw in date : 
        zw1 = ''
        if year   : zw1 = str(zw.year)+'.'
        if month  : zw1 = zw1+str(zw.month) +'.'
        if day    : zw1 = zw1+str(zw.day)   +'.'
        if hour   : zw1 = zw1+str(zw.hour)  +'.'
        if minute : zw1 = zw1+str(zw.minute)+'.'
        if second : zw1 = zw1+str(zw.second)+'.'
        output.append(zw1)
    #
    return output
# END cdtime2str
####################################################################################################
